import ReactDOM from "react-dom";

ReactDOM.render("Confia q esse negocio vai dar bom", document.getElementById("app"));
ReactDOM.render("Vai dar bom dms ó", document.getElementById("root"));
